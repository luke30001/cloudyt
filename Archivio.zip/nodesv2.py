import socket,threading
import os
import ast
import ecdsa
from ecdsa import SigningKey, VerifyingKey,SECP256k1
import base64
import binascii,base58,hashlib
import requests
from cryptography.fernet import Fernet
import binascii
def createsocket(data):
    if data[0]!=ip():
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.connect(data)
        return server
    else:
        raise ValueError("Autoconnection issue")
defport=1121
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("0.0.0.0",defport))
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
ipd=False
def ip(publ=False):
    if not publ:
        if not ipd:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8",80))
            ip=s.getsockname()[0]
            s.close()
            return ip
        else:
            return ipd
    else:
        return requests.get('https://api.ipify.org').text
def recv_all(conn):
    conn.settimeout(20000)
    lm=b""
    msg=b""
    while "theeeend" not in lm.decode("utf-8"):
        print(lm)
        if lm!=None:
            msg+=lm
        lm=conn.recv(1024)
    msg+=lm
    try:
        return ast.literal_eval(msg.decode()[:-8])
    except:
        return msg.decode()[:-8]
def send_all(conn,msg):
    conn.sendall(str(msg).encode())
    conn.sendall(b"theeeend")
def touch(ff):
    if not os.path.isfile(ff):
        with open(ff, 'w') as file:
            pass
def get_nodes():
    touch("nodes")
    f=open("nodes","r")
    jj=None
    try:
        jj=ast.literal_eval(f.read())
    except:
        jj={}
    f.close()
    return jj
def update_nodes(jj):
    f=open("nodes","w+")
    f.write(str(jj))
    f.close()
update_nodes({})
def login():
    pk=input("Give me your .pem file path:")
    f=open(pk,"r")
    keyp=f.read()
    f.close()
    return SigningKey.from_pem(keyp)
def sign(pk,msg):
    try:
        return pk.sign(msg.encode("utf-8"))
    except:
        return pk.sign(msg)
def verify(pub,msg,sign):
    try:
        return pub.verify(sign,msg.encode("utf-8"))
    except:
        return pub.verify(sign,msg)
##to delete
def adre(pub):
    hash = hashlib.sha256(pub).digest()
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(hash)
    hash2 = ripemd160.digest()
    part1 = b'\x00'+hash2
    part2 = hashlib.sha256(hashlib.sha256(part1).digest()).digest()[:4]
    address=part1+part2
    return base58.b58encode(address).decode('utf-8')
##stop

def pubb(pk):
    return pk.get_verifying_key().to_string()
pk=login()
pub=pubb(pk)
if(input("Do you want to be a genesis node?(y/n):")!="y"):
    ii=input("Give me entry node ip:")
    pp=input("Give me entry node port:")
    signed_hello=sign(pk,"hello")
    helloer=createsocket((ii,int(pp)))
    jj={"msg":"hello","sig":signed_hello,"key":pub,"pp":defport,"ii":ip()}
    send_all(helloer,jj)
    list_nodes=recv_all(helloer)
    iptobyp=helloer.getpeername()[0]
    helloer.close()
    signed_hello2=sign(pk,"hello2")
    jj={"msg":"hello2","sig":signed_hello2,"key":pub,"pp":defport,"ii":ip()}
    todel=[]
    for k,v in list_nodes.items():
        try:
            helloer=createsocket(v)
            send_all(helloer,jj)
            helloer.close()
        except Exception as error:
            print(error)
            todel.append(k)
    for v in todel:
        list_nodes.pop(v)
    update_nodes(list_nodes)
f=open("file_enc.key")
fer = Fernet(f.read())
f.close()
def getdirsiz(directory):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(directory):
        for f in filenames:
            file_path = os.path.join(dirpath, f)
            if os.path.isfile(file_path):
                total_size += os.path.getsize(file_path)
    return total_size/ (1024 * 1024)
def cleardir(directory):
    try:
        for dirpath, dirnames, filenames in os.walk(directory):
            for f in filenames:
                file_path = os.path.join(dirpath, f)
                if os.path.isfile(file_path):
                    os.remove(file_path)
        return True
    except:
        return False
def hash(msg):
    return hashlib.sha256(msg).digest()
def upload(rcv,slot):
    global linked_account,sec_account
    slt=""
    print(rcv["data"])
    if slot==2:
        slt="secondary_slot"
    else:
        slt="security_slot"
    sighash=rcv["sighash"]
    hashex=rcv["hash"]
    path=slt+"/"+hashex
    if not os.path.exists(path):
        if rcv["key"]==linked_account:
            pubk=VerifyingKey.from_string(rcv["key"],curve=SECP256k1)
            if verify(pubk,rcv["hash"],rcv["sighash"]):
                hashtover=binascii.hexlify(hash(rcv["data"])).decode()
                print(hashtover)
                if hashex==hashtover:
                    if getdirsiz(slt)<10240:
                        print(path)
                        f=open(path,"wb+")
                        f.write(rcv["data"])
                        f.close()
                        send_all(conn,"200")
                    else:
                        send_all(conn,"size_limit")
                else:
                    send_all(conn,"hash comparison failed")
            else:
                send_all(conn,"invalid sig")
        else:
            send_all(conn,"no permission")
    else:
        send_all(conn,"already exists")
def backup(conn):
    global fer,pk
    for dirpath, dirnames, filenames in os.walk("main_slot"):
        for v in filenames:
            f=open(os.path.join(dirpath,v),"rb")
            data=fer.encrypt(f.read())
            print(data)
            hh=binascii.hexlify(hash(data)).decode()
            print(hh)
            send_all(conn,{"msg":"upload","data":data,"hash":hh,"sighash":sign(pk,hh),"key":pub})
            f.close()
            log=recv_all(conn)
    send_all(conn,"end")
cleardir("secondary_slot")
cleardir("security_slot")
server.listen()
linked_account=None
sec_account=None
temp=True
for k,v in get_nodes().items():
    link_searcher=createsocket(v)
    send_all(link_searcher,{"msg":"free?","pub":pub})
    rcv=recv_all(link_searcher)
    if rcv["msg"]=="yes":
        linked_account=rcv["pub"]
        backup(link_searcher)
        next_file=recv_all(link_searcher)
        while(next_file!="end"):
            upload(next_file,2)
            next_file=recv_all(link_searcher)
        link_searcher.close()
        temp=False
        break
    link_searcher.close()
if temp:
    for k,v in get_nodes().items():
        link_searcher=createsocket(v)
        send_all(link_searcher,{"msg":"temp-free?","pub":pub})
        rcv=recv_all(link_searcher)
        if rcv["msg"]=="yes":
            sec_account=rcv["pub"]
            backup(link_searcher)
            next_file=recv_all(link_searcher)
            while(next_file!="end"):
                upload(next_file,3)
                next_file=recv_all(link_searcher)
            link_searcher.close()
            break
        link_searcher.close()
def handler(conn,addr):
    global pub,linked_account,sec_account
    conn.settimeout(20000)
    rcv=recv_all(conn)
    if rcv["msg"]=="hello":
        print(rcv["key"])
        pubk=VerifyingKey.from_string(rcv["key"],curve=SECP256k1)
        if verify(pubk,rcv["msg"],rcv["sig"]):
            noth=get_nodes()
            noth[pub]=(ip(),defport)
            send_all(conn,noth)
            noth[rcv["key"]]=(rcv["ii"],rcv["pp"])
            del noth[pub]
            update_nodes(noth)
    if rcv["msg"]=="hello2":
        pubk=VerifyingKey.from_string(rcv["key"],curve=SECP256k1)
        if verify(pubk,rcv["msg"],rcv["sig"]):
            noth=get_nodes()
            noth[rcv["key"]]=(rcv["ii"],rcv["pp"])
            update_nodes(noth)
    if rcv["msg"]=="free?":
        if linked_account==None:
            send_all(conn,{"msg":"yes","pub":pub})
            linked_account=rcv["pub"]
            next_file=recv_all(conn)
            while(next_file!="end"):
                upload(next_file,2)
                next_file=recv_all(conn)
            backup(conn)
        else:
            send_all(conn,"no")
    if rcv["msg"]=="temp-free?":
        if sec_account==None:
            send_all(conn,{"msg":"yes","pub":pub})
            sec_account=rcv["pub"]
            next_file=recv_all(conn)
            while(next_file!="end"):
                upload(next_file,3)
                next_file=recv_all(conn)
            backup(conn)
        else:
            send_all(conn,"no")
    if rcv["msg"]=="upload":
        upload(rcv)
    conn.close()

while True:
    try:
        conn,addr=server.accept()
        thr=threading.Thread(target=handler, args=(conn, addr))
        thr.start()
    except:
        server.close()
        break